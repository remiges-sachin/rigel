package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"time"

	"github.com/remiges-tech/rigel"
	"github.com/remiges-tech/rigel/etcd"
)

func main() {
	// Create a new EtcdStorage instance
	etcdStorage, err := etcd.NewEtcdStorage([]string{"localhost:2379", "localhost:2380", "localhost:2390"})
	if err != nil {
		log.Fatalf("Failed to create EtcdStorage: %v", err)
	}

	// Create a new Rigel instance
	rigelClient := rigel.New(etcdStorage, "starmf", "ucc", 1, "dev")

	// Use the Rigel client...
	fmt.Println("Rigel client created successfully")

	// Create a context that will be cancelled after 5 seconds
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	// Get the value of "host"
	value, err := rigelClient.Get(ctx, "host")
	if err != nil {
		if errors.Is(err, context.DeadlineExceeded) {
			log.Fatalf("Get operation timed out: %v", err)
		} else {
			log.Fatalf("Failed to get value: %v", err)
		}
	}
	fmt.Printf("Host: %s\n", value)
}
